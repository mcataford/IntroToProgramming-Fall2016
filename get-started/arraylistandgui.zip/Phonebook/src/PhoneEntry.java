public class PhoneEntry {
	public String name;
	public String number;
	public String location;
	
	public PhoneEntry(String n, String num) {
		this.name = n;
		this.number = num;
		this.location = determineLocation(num);
	}
	
	public String determineLocation(String num) {
		String areaCode = num.substring(0,3);
		String location = "";
		
		if(areaCode.equals("514")) location = "Montreal, CAN";
		else if(areaCode.equals("123")) location = "Seoul, KR";
		
		return location;
	}
	
	public String toString() {
		return "NAME: " + this.name + " NUMBER: " + this.number + " LOCATION: " + this.location;
	}
}
