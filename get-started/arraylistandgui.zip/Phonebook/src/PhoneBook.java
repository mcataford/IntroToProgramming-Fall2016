import java.util.ArrayList;

public class PhoneBook {
	public ArrayList<PhoneEntry> entries;
	
	public PhoneBook() {
		this.entries = new ArrayList<PhoneEntry>();
	}
	
	public void addEntry(String name, String number) {
		PhoneEntry newEntry = new PhoneEntry(name,number);
		this.entries.add(newEntry);
	}
	
	public void printAllEntries() {
		System.out.println("Phonebook contents:");
		
		for(int i = 0 ; i < this.entries.size() ; i = i + 1) {
			PhoneEntry currentEntry = this.entries.get(i);
			System.out.println("NAME: " + currentEntry.name + " NUMBER: " + currentEntry.number + " LOCATION: " + currentEntry.location);
		}
	}
	
	public int getSize() { return this.entries.size(); }
	
	public PhoneEntry getEntry(int index) {
		if(index >= 0 || index < this.getSize()) return this.entries.get(index);
		else return null;
	}
}
