public class Driver {

	public static void main(String[] args) {
		PhoneBook myBook = new PhoneBook();
		
		myBook.addEntry("Bob","5142351677");
		myBook.addEntry("Marie","5145687452");
		myBook.addEntry("Sergio","1235689746");
		myBook.addEntry("Nelly","5142357845");
		
		myBook.printAllEntries();
		
	}

}
