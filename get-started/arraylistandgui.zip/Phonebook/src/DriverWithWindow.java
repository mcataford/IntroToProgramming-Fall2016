import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DriverWithWindow {
	//Visual elements
	public static JFrame window;
	public static JTextArea entryList;
	public static JTextField nameField;
	public static JTextField numberField;
	public static PhoneBook myBook;
	
	
	public static void main(String[] args) {
		//Creating the book
		myBook = new PhoneBook();
		
		//Adding a few entries to have a non-empty book to start with
		myBook.addEntry("Bob","5142351677");
		myBook.addEntry("Marie","5145687452");
		myBook.addEntry("Sergio","1235689746");
		myBook.addEntry("Nelly","5142357845");
		
		//Creating a window to display
		window = new JFrame("My phonebook");
		
		//These two settings set the size of the window and make sure that the close button will close the app.
		window.setSize(500,500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Creating the two panels that will hold our elements
		JPanel textpanel = new JPanel();
		JPanel editpanel = new JPanel();
		
		//Setting up the text area in which our items appear
		entryList = new JTextArea();
		
		//Making sure that it's not editable
		entryList.setEditable(false);
		
		//Setting up the button that will allow the user to add to the list
		JButton submitBtn = new JButton("Add to book");
		
		//Making sure that the button does something
		submitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String number = numberField.getText();
                
                myBook.addEntry(name, number);
                entryList.append(myBook.getEntry(myBook.getSize()-1).toString()+"\n");
                
                window.repaint();
            }
        });
		
		//Setting up the fields in which the user can enter a name and a number.
		nameField = new JTextField();
		nameField.setPreferredSize(new Dimension(100,30));
		
		numberField = new JTextField();
		numberField.setPreferredSize(new Dimension(100,30));
		
		for(int i = 0 ; i < myBook.getSize() ; i = i + 1) {
			entryList.append(myBook.getEntry(i).toString()+"\n");
		}
		
		//Adding all elements on the panels
		textpanel.add(entryList);
		editpanel.add(nameField);
		editpanel.add(numberField);
		editpanel.add(submitBtn);
		
		//Adding the panels to the container
		Container contentPane = window.getContentPane();
		contentPane.add(textpanel, BorderLayout.CENTER);
		contentPane.add(editpanel, BorderLayout.PAGE_END);
		
		//Making everything visible
		window.setVisible(true);
		
		
	}
}
