/*
 * It all starts by importing the ArrayList class so we can use it!
 */

import java.util.ArrayList;
import java.util.Scanner;

public class TheArrayList {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		
		/*
		 * Arraylists can store one type of variable. You declare that type in the < > brackets next to the keyword ArrayList when you create it.
		 * To create an ArrayList, remember that it's an object. You can then write the following:
		 * 
		 * ArrayList<type> myList = new ArrayList<type>();
		 */
		
		ArrayList<String> myList = new ArrayList<String>();
		
		//Printing the instructions
		System.out.println("Enter some strings to store in our list, type 'done'.");
		
		//Run the loop until it is broken.
		while(true) {
			//Get the user input
			String input = userInput.next();
			
			//Check for the exit condition
			if(input.equals("done")) break;
			
			//Adding the input to the list
			myList.add(input);
			
			//Printing the current list
			System.out.println("\nCurrent list contents:");
			for(int i = 0 ; i < myList.size(); i = i + 1) {
				System.out.println(myList.get(i));
			}
		}
		
		//Before quitting, printing the whole list.
		System.out.println("You typed done, here's the final list:");
		for(int i = 0 ; i < myList.size(); i = i + 1) {
			System.out.println(myList.get(i));
		}
		
		userInput.close();
	}

}
