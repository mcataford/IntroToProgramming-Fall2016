public class PhoneEntry {
	public String name;
	public String number;
	public String city;
	
	public PhoneEntry(String n, String nu) {
		this.name = n;
		this.number = nu;
		determineLocation();
	}
	
	public void printEverything() {
		System.out.println("NAME: " + this.name + " NUMBER: " + this.number + " CITY: " + this.city);
	}
	
	public void determineLocation() {
		String[] areaCodes = {"111","222","514"};
		String[] cities = {"London, GB", "Seoul, KR", "Montreal, QC"};
		boolean isInCity;
		
		//Loop through all area codes
		for(int i = 0 ; i < areaCodes.length ; i = i + 1) {
			isInCity = true;
			
			//Loop through the first 3 characters of the area AND of the number
			for(int j = 0 ; j < 3 ; j = j + 1) {
				if(areaCodes[i].charAt(j) != this.number.charAt(j)) {
					isInCity = false;
				}
			}
			
			if(isInCity == true) {
				this.city = cities[i];
				break;
			} else {
				this.city = "Error";
			}
		}
		

	}
	
}
