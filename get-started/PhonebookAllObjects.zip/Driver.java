public class Driver {
	public static void main(String[] args) {
		PhoneBook ourBook = new PhoneBook();
		
		ourBook.addEntry("Bob", "111-222-3333");
		ourBook.addEntry("Marie", "222-272-3733");
		ourBook.addEntry("Joe", "111-222-3393");
		ourBook.addEntry("Khatira", "222-242-6333");
		
		ourBook.printAllEntries();
		ourBook.saveToFile();
	}
}
