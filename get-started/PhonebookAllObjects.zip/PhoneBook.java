import java.util.ArrayList;
import java.io.PrintWriter;

public class PhoneBook {
	public ArrayList<PhoneEntry> entries;
	
	public PhoneBook() {
		this.entries = new ArrayList<PhoneEntry>();
	}
	
	public void addEntry(String name, String number) {
		PhoneEntry newEntry = new PhoneEntry(name,number);
		this.entries.add(newEntry);
	}
	
	public void removeEntryByName(String name) {
		int i;
		for(i = 0 ; i < this.entries.size() ; i = i + 1) {
			if(this.entries.get(i).name.equals(name)) {
				this.entries.remove(i);
				break;
			}
		}
	}
	
	public void removeEntryByNumber(String number) {
		int i;
		for(i = 0 ; i < this.entries.size() ; i = i + 1) {
			if(this.entries.get(i).number.equals(number)) {
				this.entries.remove(i);
				break;
			}
		}
	}
	
	public void printAllEntries() {
		int i;
		for(i = 0 ; i < this.entries.size(); i = i + 1) {
			System.out.println("Name: " + this.entries.get(i).name + " Number: " + this.entries.get(i).number + " Location: " + this.entries.get(i).city);
		}
	}
	
	public void saveToFile() {
		int i;
		
		try{
		    PrintWriter writer = new PrintWriter("phonebook.txt", "UTF-8");
		    for(i = 0 ; i < this.entries.size() ; i = i + 1) {
		    	PhoneEntry current = this.entries.get(i);
		    	writer.print(current.name + " " + current.number + " " + current.city+ "\n");
		    }
		    writer.close();
		} catch (Exception e) {
		   // do something
		}
	}
}
